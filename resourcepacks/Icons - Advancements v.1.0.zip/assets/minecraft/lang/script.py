#!/usr/bin/env python3
import os
import sys
import re

# --- Use the script's directory, not the working directory ---
script_dir = os.path.dirname(os.path.abspath(__file__))
lang_folder = script_dir
en_us_file = os.path.join(lang_folder, "en_us.json")

if not os.path.isfile(en_us_file):
    print("❌ en_us.json not found next to the script")
    sys.exit(1)

# --- Read en_us.json as raw text ---
with open(en_us_file, "r", encoding="utf-8") as f:
    en_text = f.read()

# --- Extract allowed keys ---
KEY_RE = re.compile(r'^\s*"([^"]+)"\s*:', re.MULTILINE)
allowed_keys = set(KEY_RE.findall(en_text))

if not allowed_keys:
    print("⚠️ No keys found in en_us.json")
    sys.exit(0)

# --- Filter helper ---
def filter_keys(json_text, allowed_keys):
    lines = json_text.splitlines()
    kept_lines = []

    for line in lines:
        m = re.match(r'\s*"([^"]+)"\s*:', line)
        if m:
            key = m.group(1)
            if key not in allowed_keys:
                continue  # drop this key
        kept_lines.append(line)

    # Remove dangling commas before closing brace
    result = "\n".join(kept_lines)
    result = re.sub(r",\s*\n(\s*})", r"\n\1", result)
    return result

# --- Process all lang files ---
for filename in os.listdir(lang_folder):
    if not filename.lower().endswith(".json"):
        continue

    # Optionally skip en_us.json itself (safe either way)
    if filename == "en_us.json":
        print("ℹ️  Skipping en_us.json")
        continue

    path = os.path.join(lang_folder, filename)

    with open(path, "r", encoding="utf-8") as f:
        text = f.read()

    new_text = filter_keys(text, allowed_keys)

    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(new_text)

    print(f"✅ Filtered {filename}")

print("\n✅ Done — all language files now match en_us.json keys.")
